import React from 'react';


import LyftVehicleInspectionScreen from "../../Screens/LyftVehicleInspectionScreen";

const LyftInspectionContainer = () => {
    return <LyftVehicleInspectionScreen/>;
};
export default LyftInspectionContainer;
