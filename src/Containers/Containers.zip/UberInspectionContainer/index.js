import React from 'react';


import UberVehicleInspectionScreen from "../../Screens/UberVehicleInspectionScreen";

const UberInspectionContainer = () => {
    return <UberVehicleInspectionScreen/>;
};
export default UberInspectionContainer;
